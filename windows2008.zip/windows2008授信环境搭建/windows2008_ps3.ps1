# Powershell script to upgrade a PowerShell 2.0 system to PowerShell 3.0
# based on http://occasionalutility.blogspot.com/2013/11/everyday-powershell-part-7-powershell.html
#
# some Ansible modules that may use Powershell 3 features, so systems may need
# to be upgraded.  This may be used by a sample playbook.  Refer to the windows
# documentation on docs.ansible.com for details.
# 
# - hosts: windows
#   tasks:
#     - script: upgrade_to_ps3.ps1

#部分未升级2008不支持taskkill命令，后续补充完善
#test ports

#function Search-And-Destroy
#{
#    param ( [Parameter(Mandatory=$true)][string]$port )
#    $lines = netstat -a -o -n | findstr $port
#    $ports = @()
#
#    ForEach($line In $lines)
#    {
#        $res = $($lines -split '\s+')
#        $ports += $res[5]
#    }
#
#    $ports = $ports | select -uniq
#
#    ForEach($port In $ports)
#    {
#        $kr = $(taskkill /F /PID $port)
#        if($kr.HasSucceeded)
#   {
#        echo "$port is killed and 5986 is ok"
#   }
#   else
#   {
#        echo "please kill the process $port to release port 5986"
#        exit 1
#   }
#    }
#}
#Search-And-Destroy(5986)


#$tcp=new-object System.Net.Sockets.TcpClient 
#try
#{$tcp.connect("localhost",5986)
#    $portcheck=netsh advfirewall firewall show rule name="Allow WinRM HTTPS"
#    $portcount=$portcheck|findstr "5986"
#    Write-Host "5986 已存在."
#    if($portcount -lt 1){
#    Write-Host "port is already in used,please release the port or change another one端口已被占用，请解除占用或更改其他端口." -ForegroundColor Red
#    $tcp.close() 
#    exit}
#    Write-Host "端口已分配给winrm，可继续后续配置." -ForegroundColor Green
#} 
#catch
#{
#    Write-Host "port is ok端口可用." -ForegroundColor Green    
#}



Function Write-Log
{
    $Message = $args[0]
    Write-EventLog -LogName Application -Source $EventSource -EntryType Information -EventId 1 -Message $Message
}

Function Write-VerboseLog
{
    $Message = $args[0]
    Write-Verbose $Message
    Write-Log $Message
}

function download-file
{
    param ([string]$path, [string]$local)
    $client = new-object system.net.WebClient
    $client.Headers.Add("user-agent", "PowerShell")
    $client.downloadfile($path, $local)
}


$winpath = "C:\Users\Administrator\Downloads"

if (!(test-path $winpath))
{
    New-Item -ItemType directory -Path $winpath
}

# Get version of OS

# 6.0 is 2008
# 6.1 is 2008 R2
# 6.2 is 2012
# 6.3 is 2012 R2


if ($PSVersionTable.psversion.Major -ge 3)
{   
    write-host "Powershell 3 Installed already; You don't need this"
    $architecture = $ENV:PROCESSOR_ARCHITECTURE
    if ($architecture -eq "AMD64")
{
    $DownloadUrlWin = "http://download.windowsupdate.com/d/msdownload/update/software/htfx/2013/07/windows8-rt-kb2842230-x64_6b06f4059b82eaa8140e91e9f30c7b3a72640741.msu"
    $DownloadUrlTSL = "https://download.microsoft.com/download/F/4/1/F4154AD2-2119-48B4-BF99-CC15F68E110D/Windows6.1-KB3080079-x64.msu"
}
    else
{
    $DownloadUrlWin = "http://download.windowsupdate.com/d/msdownload/update/software/htfx/2013/07/windows8-rt-kb2842230-x86_ba30b9f56e801eb6dc4915312514340c613780fc.msu"
    $DownloadUrlTSL = "https://download.microsoft.com/download/B/0/7/B07C5172-54DE-451E-AE10-C3F876FFFC1B/Windows6.1-KB3080079-ia64.msu"
}



$FileNameWin = $DownLoadUrlWin.Split('/')[-1]
$FileNameTSL = $DownloadUrlTSL.Split('/')[-1]

download-file $downloadurlwin "$winpath\$filenamewin"
download-file $downloadurltsl "$winpath\$filenametsl"

Write-Verbose "start install hotfix."

Start-Process -FilePath "$winpath\$filenamewin" -ArgumentList /quiet
Start-Process -FilePath "$winpath\$filenametsl" -ArgumentList /quiet

Restart-Computer -Force

}

$powershellpath = "C:\powershell"



if (!(test-path $powershellpath))
{
    New-Item -ItemType directory -Path $powershellpath
}


# .NET Framework 4.0 is necessary.

#if (($PSVersionTable.CLRVersion.Major) -lt 2)
#{
#    $DownloadUrl = "http://download.microsoft.com/download/B/A/4/BA4A7E71-2906-4B2D-A0E1-80CF16844F5F/dotNetFx45_Full_x86_x64.exe"
#    $FileName = $DownLoadUrl.Split('/')[-1]
#    download-file $downloadurl "$powershellpath\$filename"
#    ."$powershellpath\$filename" /quiet /norestart
#}

#You may need to reboot after the .NET install if so just run the script again.

# If the Operating System is above 6.2, then you already have PowerShell Version > 3
if ([Environment]::OSVersion.Version.Major -gt 6)
{
    write-host "OS is new; upgrade not needed."
    Exit
}


$osminor = [environment]::OSVersion.Version.Minor

$architecture = $ENV:PROCESSOR_ARCHITECTURE

if ($architecture -eq "AMD64")
{
    $architecture = "x64"
}  
else
{
    $architecture = "x86" 
} 

if ($osminor -eq 1)
{   
    Write-Verbose "2008 powershell url."
    $DownloadUrl = "http://download.microsoft.com/download/E/7/6/E76850B8-DA6E-4FF5-8CCE-A24FC513FD16/Windows6.1-KB2506143-" + $architecture + ".msu"
}
elseif ($osminor -eq 0)
{
    $DownloadUrl = "http://download.microsoft.com/download/E/7/6/E76850B8-DA6E-4FF5-8CCE-A24FC513FD16/Windows6.0-KB2506146-" + $architecture + ".msu"
}
else
{
    # Nothing to do; In theory this point will never be reached.
    Exit
}

$FileName = $DownLoadUrl.Split('/')[-1]
download-file $downloadurl "$powershellpath\$filename"

Write-Verbose "start install powershell3."

Start-Process -FilePath "$powershellpath\$filename" -ArgumentList /quiet


#install hotfix of windows KB2842230

#$architecture = $ENV:PROCESSOR_ARCHITECTURE

#if ($architecture -eq "AMD64")
#{
#    $architecture = "x64"
#}  
#else
#{
#    $architecture = "x86" 
#} 


$winpath = "C:\Users\Administrator\Downloads"

if (!(test-path $winpath))
{
    New-Item -ItemType directory -Path $winpath
}



if ($architecture -eq "AMD64")
{
    $DownloadUrlWin = "http://download.windowsupdate.com/d/msdownload/update/software/htfx/2013/07/windows8-rt-kb2842230-x64_6b06f4059b82eaa8140e91e9f30c7b3a72640741.msu"
    $DownloadUrlTSL = "https://download.microsoft.com/download/F/4/1/F4154AD2-2119-48B4-BF99-CC15F68E110D/Windows6.1-KB3080079-x64.msu"
}
else
{
    $DownloadUrlWin = "http://download.windowsupdate.com/d/msdownload/update/software/htfx/2013/07/windows8-rt-kb2842230-x86_ba30b9f56e801eb6dc4915312514340c613780fc.msu"
    $DownloadUrlTSL = "https://download.microsoft.com/download/B/0/7/B07C5172-54DE-451E-AE10-C3F876FFFC1B/Windows6.1-KB3080079-ia64.msu"
}



$FileNameWin = $DownLoadUrlWin.Split('/')[-1]
$FileNameTSL = $DownloadUrlTSL.Split('/')[-1]

download-file $downloadurlwin "$winpath\$filenamewin"
download-file $downloadurltsl "$winpath\$filenametsl"

Write-Verbose "start install hotfix."

Start-Process -FilePath "$winpath\$filenamewin" -ArgumentList /quiet
Start-Process -FilePath "$winpath\$filenametsl" -ArgumentList /quiet

Restart-Computer -Force